//Vinh Tuan Dat NGUYEN
//40180660 
//Assignment 1
//Prof Ali Jannatpour
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int confirm_response(int need_confirmation);
int start_program(int mode, char* word, char* file_name);
