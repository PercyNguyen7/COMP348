//Vinh Tuan Dat NGUYEN
//40180660 
//Assignment 1
//Prof Ali Jannatpour
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fileread.h"
#include "wreplace.h"
#include "ui.h"

int verifyMode(char* command);
int verifyWord(char* word);


