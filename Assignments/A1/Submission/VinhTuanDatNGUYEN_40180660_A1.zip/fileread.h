//Vinh Tuan Dat NGUYEN
//40180660 
//Assignment 1
//Prof Ali Jannatpour
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* read_line(char* filename, int target_line);
void write_line(char *filename, int target_line, char* new_text);
